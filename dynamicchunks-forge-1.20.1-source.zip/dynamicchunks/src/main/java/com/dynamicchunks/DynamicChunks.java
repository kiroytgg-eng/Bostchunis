package com.dynamicchunks;

import net.minecraftforge.fml.IExtensionPoint;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;

@Mod(DynamicChunks.MOD_ID)
public class DynamicChunks {
    public static final String MOD_ID = "dynamicchunks";

    public DynamicChunks() {
        // Mod solo de cliente: no exige que el servidor lo tenga.
        ModLoadingContext.get().registerExtensionPoint(
                IExtensionPoint.DisplayTest.class,
                () -> new IExtensionPoint.DisplayTest(
                        () -> IExtensionPoint.DisplayTest.IGNORESERVERONLY,
                        (remote, isServer) -> true));

        ModLoadingContext.get().registerConfig(ModConfig.Type.CLIENT, DCConfig.SPEC);
    }
}
