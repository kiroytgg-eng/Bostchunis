package com.dynamicchunks;

import net.minecraftforge.common.ForgeConfigSpec;

public class DCConfig {
    public static final ForgeConfigSpec SPEC;

    public static final ForgeConfigSpec.BooleanValue ENABLED;
    public static final ForgeConfigSpec.IntValue TARGET_FPS;
    public static final ForgeConfigSpec.IntValue MIN_DISTANCE;
    public static final ForgeConfigSpec.IntValue MAX_DISTANCE;
    public static final ForgeConfigSpec.IntValue CHECK_SECONDS;
    public static final ForgeConfigSpec.IntValue STEP;
    public static final ForgeConfigSpec.BooleanValue SHOW_MESSAGES;

    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();
        b.push("dynamic_chunks");

        ENABLED = b.comment("Activa o desactiva el ajuste automatico.")
                .define("enabled", true);

        TARGET_FPS = b.comment("FPS minimos que quieres mantener. Si bajas de aqui, se reducen los chunks.")
                .defineInRange("targetFps", 60, 20, 360);

        MIN_DISTANCE = b.comment("Distancia de renderizado minima (nunca bajara de esto).")
                .defineInRange("minDistance", 6, 2, 32);

        MAX_DISTANCE = b.comment("Distancia de renderizado maxima (nunca subira de esto). Vanilla permite hasta 32.")
                .defineInRange("maxDistance", 24, 2, 32);

        CHECK_SECONDS = b.comment("Cada cuantos segundos se mide el FPS promedio y se decide si cambiar.")
                .defineInRange("checkSeconds", 3, 1, 30);

        STEP = b.comment("Cuantos chunks se suben o bajan en cada ajuste.")
                .defineInRange("step", 1, 1, 4);

        SHOW_MESSAGES = b.comment("Muestra un aviso en la barra de acciones cuando cambia la distancia.")
                .define("showMessages", true);

        b.pop();
        SPEC = b.build();
    }
}
