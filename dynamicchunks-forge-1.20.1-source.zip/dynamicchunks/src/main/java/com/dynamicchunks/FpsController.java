package com.dynamicchunks;

import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ClientPlayerNetworkEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = DynamicChunks.MOD_ID, value = Dist.CLIENT)
public class FpsController {
    private static final long SECOND = 1_000_000_000L;

    private static long windowStart = 0;
    private static int frames = 0;
    private static long settleUntil = 0;     // espera tras un cambio (los chunks se reconstruyen)
    private static long noIncreaseUntil = 0; // evita subir justo despues de bajar (anti-oscilacion)

    private static void resetWindow() {
        windowStart = 0;
        frames = 0;
    }

    @SubscribeEvent
    public static void onLogin(ClientPlayerNetworkEvent.LoggingIn event) {
        // Al entrar a un mundo los FPS son bajos por la carga inicial: damos 10 s de margen.
        settleUntil = System.nanoTime() + 10 * SECOND;
        noIncreaseUntil = 0;
        resetWindow();
    }

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        while (ClientSetup.TOGGLE_KEY.consumeClick()) {
            boolean now = !DCConfig.ENABLED.get();
            DCConfig.ENABLED.set(now);
            DCConfig.ENABLED.save();
            resetWindow();
            if (mc.player != null) {
                mc.player.displayClientMessage(Component.translatable(
                        now ? "message.dynamicchunks.on" : "message.dynamicchunks.off"), true);
            }
        }
    }

    @SubscribeEvent
    public static void onRenderTick(TickEvent.RenderTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;

        Minecraft mc = Minecraft.getInstance();
        if (!DCConfig.ENABLED.get()
                || mc.level == null
                || mc.player == null
                || mc.isPaused()
                || !mc.isWindowActive()) {
            resetWindow();
            return;
        }

        long now = System.nanoTime();
        if (windowStart == 0) {
            windowStart = now;
            frames = 0;
            return;
        }

        frames++;
        long elapsed = now - windowStart;
        if (elapsed < DCConfig.CHECK_SECONDS.get() * SECOND) return;

        double fps = frames / (elapsed / (double) SECOND);
        resetWindow();

        if (now < settleUntil) return;
        evaluate(mc, fps, now);
    }

    private static void evaluate(Minecraft mc, double fps, long now) {
        int target = DCConfig.TARGET_FPS.get();
        int min = DCConfig.MIN_DISTANCE.get();
        int max = Math.max(min, DCConfig.MAX_DISTANCE.get());
        int step = DCConfig.STEP.get();
        int current = mc.options.renderDistance().get();

        // Si tienes limite de FPS (ej. 60), nunca pasaras de ahi: ajustamos los umbrales.
        int limit = mc.options.framerateLimit().get();
        double cap = limit < 260 ? limit : Double.MAX_VALUE;
        double low = Math.min(target, cap * 0.90);
        double high = Math.min(target * 1.20, cap * 0.95);
        if (high < low + 2) high = low + 2;

        int next = current;
        if (fps < low && current > min) {
            // Caida fuerte de FPS: bajamos el doble de rapido.
            int amount = fps < low * 0.6 ? step * 2 : step;
            next = Math.max(min, current - amount);
            noIncreaseUntil = now + 30 * SECOND;
        } else if (fps > high && current < max && now >= noIncreaseUntil) {
            next = Math.min(max, current + step);
        }

        if (next != current) {
            mc.options.renderDistance().set(next);
            settleUntil = now + (DCConfig.CHECK_SECONDS.get() + 2L) * SECOND;
            if (DCConfig.SHOW_MESSAGES.get() && mc.player != null) {
                mc.player.displayClientMessage(Component.translatable(
                        "message.dynamicchunks.changed",
                        String.valueOf(current), String.valueOf(next), String.valueOf(Math.round(fps))), true);
            }
        }
    }
}
