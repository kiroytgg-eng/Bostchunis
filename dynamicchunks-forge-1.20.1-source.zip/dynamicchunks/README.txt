DYNAMIC CHUNKS - Forge 1.20.1 (solo cliente)

COMPILAR (Java 17):
1. Descarga el MDK de Forge 1.20.1 (files.minecraftforge.net).
2. Copia de ese MDK a esta carpeta: gradlew, gradlew.bat y la carpeta gradle/
3. Ejecuta:  ./gradlew build     (Windows: gradlew build)
4. El mod queda en build/libs/dynamicchunks-forge-1.20.1-1.0.0.jar
   Ponlo en la carpeta mods.

CONFIG: config/dynamicchunks-client.toml
TECLA:  Opciones > Controles > Dynamic Chunks (sin tecla por defecto)
